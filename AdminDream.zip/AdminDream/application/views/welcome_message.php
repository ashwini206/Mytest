<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<input type="text" class="form-control custom-search" name="category_search_name" id="category_search_name" placeholder="Search term...">
<div>
	<ul id="more_result"></ul>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
<script>
	function addText(Textval){
		$('#category_search_name').val(Textval);
		$('#more_result').empty();
	}
 
	$(document).ready(function(){
		// this focus event while you are focusing on an input element.If you enter some text on this input ,its will be passing data in the category-search-name URL.
		$('#category_search_name').on('keyup',function(){
			// Get value from the search box
			var search_text = $('#category_search_name').val();
			// check value is exist or not
			if(search_text==""){
	  			$('#more_result').empty();
	  		}else{
				$.ajax({
					type: "POST", // data pass by POST method.
					url: "category-search-name", // This is the URL link where you sent the data.
					data: {search_name: search_text}, // search_text value store in the search_name variable and pass variable data by POST method.
					success: function(html){
						console.log(html); // you can check result in the browser console.
						$("#more_result").html(html).show(); // when data get display a list "more_result" is the "UL" tag id name.
					}
				});
			}
		});
	});
</script>